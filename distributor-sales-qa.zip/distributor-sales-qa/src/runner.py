"""Executes registered checks and turns Outcomes into CheckResults (+ evidence CSV files)."""
from __future__ import annotations

import re
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Iterable, List

import pandas as pd

from src.context import QAContext
from src.logger import get_logger
from src.registry import CheckSpec
from src.results import ERROR, FAIL, PASS, SKIPPED, CheckResult, PrerequisiteError

log = get_logger("runner")


def run_check(spec: CheckSpec, ctx: QAContext, evidence_dir: Path | None = None) -> CheckResult:
    started = time.perf_counter()
    status, total, failed_n, message, evidence_file = PASS, 0, 0, "", ""
    log.info("[%s] START  %s", spec.test_id, spec.title)
    try:
        for req in spec.requires:                      # fail fast on missing prerequisites
            if req in ("dist", "fact", "cust"):
                ctx.raw(req)
            elif req.startswith("db"):
                ctx.db
                if req != "db":
                    ctx.db_raw(req.split(":", 1)[1])
        out = spec.func(ctx)
        total, failed_n, message = out.total, out.failed_count, out.message
        if out.skipped:
            status = SKIPPED
        elif failed_n > 0:
            status = FAIL
            if evidence_dir is not None:
                evidence_file = _write_evidence(out.failed, spec, ctx, evidence_dir)
    except PrerequisiteError as exc:
        status, message = SKIPPED, f"Prerequisite unavailable: {exc}"
    except Exception as exc:  # noqa: BLE001 - automation/environment defect, not a data defect
        status, message = ERROR, f"{type(exc).__name__}: {exc}"
        log.error("[%s] ERROR\n%s", spec.test_id, traceback.format_exc())
    duration = round(time.perf_counter() - started, 3)
    known = ctx.s.cfg.get("known_defects", {}).get(spec.test_id, "")
    log.info("[%s] %s  (%s) %s", spec.test_id, status, f"{duration}s", message[:160])
    return CheckResult(test_id=spec.test_id, module=spec.module, suite=spec.suite, title=spec.title,
                       category=spec.category, severity=spec.severity, dataset=spec.dataset,
                       defect_area=spec.defect_area, status=status, total_records=int(total),
                       failed_records=int(failed_n), message=message, evidence_file=evidence_file,
                       duration_sec=duration, executed_at=datetime.now().isoformat(timespec="seconds"),
                       known_defect=known)


def _write_evidence(df: pd.DataFrame, spec: CheckSpec, ctx: QAContext, evidence_dir: Path) -> str:
    evidence_dir.mkdir(parents=True, exist_ok=True)
    limit = int(ctx.s.execution.get("evidence_max_rows", 5000))
    name = re.sub(r"[^A-Za-z0-9_-]", "_", spec.test_id) + ".csv"
    df.head(limit).to_csv(evidence_dir / name, index=False, encoding="utf-8-sig")
    return f"evidence/{name}" + (f" (first {limit:,} of {len(df):,} rows)" if len(df) > limit else "")


def run_checks(specs: Iterable[CheckSpec], ctx: QAContext, evidence_dir: Path | None = None) -> List[CheckResult]:
    return [run_check(s, ctx, evidence_dir) for s in specs]
