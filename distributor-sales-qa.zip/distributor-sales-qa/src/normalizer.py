"""Type parsing / normalisation shared by file data and database data.

DB frames are stringified first, then parsed with the SAME code path, so source
and target are compared on identical canonical values (framework principle:
"normalise source and target before comparison").
"""
from __future__ import annotations

from typing import Dict, Tuple

import pandas as pd


def to_str(s: pd.Series) -> pd.Series:
    """Series -> plain str series, NULL/NaN/None -> ''."""
    return s.astype(object).where(s.notna(), "").astype(str)


def blank_mask(s: pd.Series) -> pd.Series:
    return to_str(s).str.strip() == ""


def _parse_dates(s: pd.Series, formats) -> pd.Series:
    out = pd.Series(pd.NaT, index=s.index, dtype="datetime64[ns]")
    remaining = s.copy()
    for fmt in formats:
        todo = out.isna() & (remaining != "")
        if not todo.any():
            break
        out.loc[todo] = pd.to_datetime(remaining[todo], format=fmt, errors="coerce")
    return out


def parse_column(raw: pd.Series, col: Dict, exec_cfg: Dict) -> Tuple[pd.Series, pd.Series]:
    """Return (parsed_series, invalid_mask). Blank values are NULL, never 'invalid'."""
    s = to_str(raw).str.strip()
    blank = s == ""
    t = col["type"]
    if t == "string":
        parsed = s.where(~blank, None)
        return parsed, pd.Series(False, index=s.index)
    if t in ("int", "decimal"):
        num = pd.to_numeric(s.where(~blank, None), errors="coerce")
        bad = ~blank & num.isna()
        if t == "int":
            bad = bad | (num.notna() & (num % 1 != 0))
            return num.round().astype("Int64").where(~bad), bad
        return num.round(col.get("scale") or 2).where(~bad), bad
    if t == "date":
        d = _parse_dates(s, exec_cfg["date_formats"])
        return d.dt.normalize(), ~blank & d.isna()
    if t == "datetime":
        d = _parse_dates(s, exec_cfg["datetime_formats"] + exec_cfg["date_formats"])
        return d, ~blank & d.isna()
    raise ValueError(f"Unsupported type {t}")


def normalize_frame(df: pd.DataFrame, table_schema: Dict, exec_cfg: Dict) -> Tuple[pd.DataFrame, pd.DataFrame]:
    typed, invalid = {}, {}
    for col in table_schema["columns"]:
        if col["name"] in df.columns:
            typed[col["name"]], invalid[col["name"]] = parse_column(df[col["name"]], col, exec_cfg)
    return pd.DataFrame(typed, index=df.index), pd.DataFrame(invalid, index=df.index)


def coerce_typed(df: pd.DataFrame, table_schema: Dict) -> pd.DataFrame:
    """Force an already-computed frame onto the canonical dtypes of `table_schema`
    (so independently computed values compare cleanly with parsed file/DB values)."""
    out = {}
    for col in table_schema["columns"]:
        n = col["name"]
        if n not in df.columns:
            continue
        s, t = df[n], col["type"]
        if t == "string":
            out[n] = s.astype(object).where(s.notna(), None)
        elif t == "int":
            out[n] = pd.to_numeric(s, errors="coerce").round().astype("Int64")
        elif t == "decimal":
            out[n] = pd.to_numeric(s, errors="coerce").astype(float).round(col.get("scale") or 2)
        elif t == "date":
            out[n] = pd.to_datetime(s, errors="coerce").dt.normalize()
        else:
            out[n] = pd.to_datetime(s, errors="coerce")
    return pd.DataFrame(out, index=df.index)
