"""Reusable validation primitives. Each returns an Outcome carrying failed-record evidence."""
from __future__ import annotations

import re
from typing import Iterable, List, Optional, Sequence

import pandas as pd

from src.normalizer import blank_mask, to_str
from src.results import Outcome


def _cols(*parts) -> List[str]:
    out: List[str] = []
    for p in parts:
        for c in ([p] if isinstance(p, str) else list(p or [])):
            if c not in out:
                out.append(c)
    return out


def rows_outcome(df: pd.DataFrame, bad: pd.Series, id_cols: Sequence[str] | str, show_cols: Sequence[str] | str,
                 reason: str, ok_msg: str = "", total: Optional[int] = None) -> Outcome:
    """Generic builder: rows where `bad` is True are failures (evidence incl. failure_reason)."""
    total = len(df) if total is None else total
    bad = bad.fillna(False).astype(bool)
    n = int(bad.sum())
    if n == 0:
        return Outcome(total=total, message=ok_msg or f"All {total:,} records passed (no violation of: {reason})")
    cols = [c for c in _cols(id_cols, show_cols) if c in df.columns]
    ev = df.loc[bad, cols].copy()
    ev["failure_reason"] = reason
    return Outcome(total=total, failed=ev.reset_index(drop=True),
                   message=f"{n:,} of {total:,} records failed: {reason}")


def mandatory(raw: pd.DataFrame, table_schema: dict, id_col: str) -> Outcome:
    """NOT NULL columns (per DDL) must be populated."""
    required = [c["name"] for c in table_schema["columns"] if not c["nullable"] and c["name"] in raw.columns]
    missing_cols = [c["name"] for c in table_schema["columns"] if not c["nullable"] and c["name"] not in raw.columns]
    parts = []
    for c in required:
        m = blank_mask(raw[c])
        if m.any():
            e = raw.loc[m, _cols(id_col, c)].copy()
            e["blank_column"] = c
            e["failure_reason"] = f"Mandatory field '{c}' is blank/null"
            parts.append(e[[id_col, "blank_column", "failure_reason"]])
    for c in missing_cols:
        parts.append(pd.DataFrame([{id_col: "(all)", "blank_column": c, "failure_reason": f"Mandatory column '{c}' missing"}]))
    total = len(raw) * max(len(required), 1)
    if not parts:
        return Outcome(total=total, message=f"All {len(required)} mandatory columns populated in all {len(raw):,} records")
    ev = pd.concat(parts, ignore_index=True)
    by_col = ev["blank_column"].value_counts().to_dict()
    return Outcome(total=total, failed=ev, message=f"{len(ev):,} blank mandatory values: {by_col}")


def unique(raw: pd.DataFrame, cols: Sequence[str] | str, show_cols: Sequence[str] = (), label: str = "") -> Outcome:
    cols = [cols] if isinstance(cols, str) else list(cols)
    label = label or "+".join(cols)
    key = raw[cols].apply(lambda s: s.astype(str).str.strip())
    dup = key.duplicated(keep=False)
    non_blank = ~(key == "").any(axis=1)
    bad = dup & non_blank
    n_keys = int(key[bad].drop_duplicates().shape[0])
    out = rows_outcome(raw, bad, cols, show_cols, f"Duplicate {label}", total=len(raw),
                       ok_msg=f"{label} is unique across all {len(raw):,} records")
    if out.failed is not None:
        out.failed = out.failed.sort_values(cols).reset_index(drop=True)
        out.message = f"{n_keys:,} duplicated {label} values affecting {int(bad.sum()):,} of {len(raw):,} records"
    return out


def pattern(raw: pd.DataFrame, col: str, regex: str, id_col: str, allow_blank: bool = True) -> Outcome:
    s = to_str(raw[col]).str.strip()
    bad = ~s.str.match(regex)
    if allow_blank:
        bad &= s != ""
    return rows_outcome(raw, bad, id_col, col, f"{col} does not match required format {regex}")


def domain(raw: pd.DataFrame, col: str, allowed: Iterable[str], id_col: str, allow_blank: bool = True,
           case_sensitive: bool = True) -> Outcome:
    s = to_str(raw[col]).str.strip()
    allowed = list(allowed)
    ok = s.isin(allowed) if case_sensitive else s.str.upper().isin([a.upper() for a in allowed])
    bad = ~ok
    if allow_blank:
        bad &= s != ""
    return rows_outcome(raw, bad, id_col, col, f"{col} not in allowed values {allowed}")


def valid_types(raw: pd.DataFrame, invalid: pd.DataFrame, cols: Sequence[str], id_col: str, what: str) -> Outcome:
    """Values that are populated but cannot be parsed to the declared type."""
    parts = []
    for c in cols:
        if c in invalid.columns and invalid[c].any():
            e = raw.loc[invalid[c], _cols(id_col, c)].copy()
            e["invalid_column"] = c
            e["invalid_value"] = e[c]
            e["failure_reason"] = f"{c} is not a valid {what}"
            parts.append(e[[id_col, "invalid_column", "invalid_value", "failure_reason"]])
    total = len(raw) * max(len(cols), 1)
    if not parts:
        return Outcome(total=total, message=f"All {what} values valid in {len(cols)} column(s)")
    ev = pd.concat(parts, ignore_index=True)
    return Outcome(total=total, failed=ev, message=f"{len(ev):,} invalid {what} value(s): {ev['invalid_column'].value_counts().to_dict()}")


def lengths(raw: pd.DataFrame, table_schema: dict, id_col: str) -> Outcome:
    """Truncation risk: value longer than DDL length."""
    parts = []
    checked = 0
    for c in table_schema["columns"]:
        if c["type"] == "string" and c["length"] and c["name"] in raw.columns:
            checked += 1
            m = to_str(raw[c["name"]]).str.len() > c["length"]
            if m.any():
                e = raw.loc[m, _cols(id_col, c["name"])].copy()
                e["column"] = c["name"]
                e["value"] = e[c["name"]]
                e["max_length"] = c["length"]
                e["failure_reason"] = f"{c['name']} exceeds VARCHAR({c['length']})"
                parts.append(e[[id_col, "column", "value", "max_length", "failure_reason"]])
    total = len(raw) * max(checked, 1)
    if not parts:
        return Outcome(total=total, message=f"No value exceeds its DDL length ({checked} text columns)")
    ev = pd.concat(parts, ignore_index=True)
    return Outcome(total=total, failed=ev, message=f"{len(ev):,} value(s) exceed DDL length")


def blank_rate(raw: pd.DataFrame, limits: dict, id_col: str) -> Outcome:
    """Optional (nullable) columns whose blank-rate exceeds the configured tolerance."""
    rows = []
    for col, max_pct in limits.items():
        if col in raw.columns:
            pct = round(100 * blank_mask(raw[col]).mean(), 2)
            if pct > max_pct:
                rows.append({"column": col, "blank_pct": pct, "tolerance_pct": max_pct,
                             "blank_records": int(blank_mask(raw[col]).sum()),
                             "failure_reason": f"{col} is {pct}% blank (tolerance {max_pct}%)"})
    if not rows:
        return Outcome(total=len(raw), message="Blank-rates of optional columns within tolerance")
    return Outcome(total=len(raw), failed=pd.DataFrame(rows), failed_total=sum(r["blank_records"] for r in rows),
                   message="; ".join(r["failure_reason"] for r in rows))


def regex_ok(value: str, regex: str) -> bool:
    return re.match(regex, value or "") is not None


def multi_rule(df: pd.DataFrame, rules: Sequence[tuple], id_cols: Sequence[str] | str, total: Optional[int] = None,
               ok_msg: str = "") -> Outcome:
    """rules = [(bad_mask, reason, show_cols), ...] -> combined evidence, one row per violation."""
    total = len(df) if total is None else total
    parts, summary = [], {}
    for mask, reason, show in rules:
        mask = mask.fillna(False).astype(bool)
        if mask.any():
            cols = [c for c in _cols(id_cols, show) if c in df.columns]
            e = df.loc[mask, cols].copy()
            e["failure_reason"] = reason
            parts.append(e)
            summary[reason] = int(mask.sum())
    if not parts:
        return Outcome(total=total, message=ok_msg or f"All {total:,} records satisfy {len(rules)} rule(s)")
    ev = pd.concat(parts, ignore_index=True)
    return Outcome(total=total, failed=ev, message="; ".join(f"{v:,} x {k}" for k, v in summary.items()))


def whitespace(raw: pd.DataFrame, id_col: str) -> Outcome:
    """Leading/trailing blanks in populated text values (join/compare breakers)."""
    parts = []
    for c in raw.columns:
        s = to_str(raw[c])
        m = (s != s.str.strip()) & (s != "")
        if m.any():
            e = raw.loc[m, _cols(id_col, c)].copy()
            e["column"], e["value"] = c, e[c].map(repr)
            e["failure_reason"] = f"{c} has leading/trailing whitespace"
            parts.append(e[[id_col, "column", "value", "failure_reason"]])
    total = raw.size
    if not parts:
        return Outcome(total=total, message="No leading/trailing whitespace found")
    ev = pd.concat(parts, ignore_index=True)
    return Outcome(total=total, failed=ev, message=f"{len(ev):,} value(s) with stray whitespace")
