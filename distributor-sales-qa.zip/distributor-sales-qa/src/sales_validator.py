"""Sales Validator module: content validation of Distributor Sales (JSON) and Fact Sales (CSV) files.

Checks: DST-001 .. DST-018 (Distributor Sales), FAC-001 .. FAC-012 (Fact Sales)
"""
from __future__ import annotations

import pandas as pd

from src import validators as v
from src.registry import qa_check
from src.results import Outcome

D_MOD, F_MOD = "Distributor Sales Validation", "Fact Sales Validation"
D_SET, F_SET = "sales_validation", "sales_validation"
DIST, FACT = "Distributor Sales (JSON)", "Fact Sales (CSV)"


def _rules(ctx):
    return ctx.s.rules


# ============================ DISTRIBUTOR SALES ============================
@qa_check("DST-001", suite=D_SET, module=D_MOD, category="Completeness", severity="Critical", dataset=DIST,
          title="Mandatory (NOT NULL) fields are populated", requires=["dist"])
def dst_mandatory(ctx):
    """DDL NOT NULL columns must not be blank/null."""
    return v.mandatory(ctx.raw("dist"), ctx.schema("dist"), "distributor_txn_id")


@qa_check("DST-002", suite=D_SET, module=D_MOD, category="Uniqueness", severity="Critical", dataset=DIST,
          title="distributor_txn_id is unique (no duplicate transactions)", requires=["dist"])
def dst_txn_unique(ctx):
    return v.unique(ctx.raw("dist"), "distributor_txn_id", ["policy_number", "gross_amount", "sale_date"], "distributor_txn_id")


@qa_check("DST-003", suite=D_SET, module=D_MOD, category="Uniqueness", severity="High", dataset=DIST,
          title="policy_number is unique (DDL unique key)", requires=["dist"])
def dst_policy_unique(ctx):
    return v.unique(ctx.raw("dist"), "policy_number", ["distributor_txn_id"], "policy_number")


@qa_check("DST-004", suite=D_SET, module=D_MOD, category="Format", severity="High", dataset=DIST,
          title="distributor_txn_id follows format DSC + 14 digits", requires=["dist"])
def dst_txn_format(ctx):
    return v.pattern(ctx.raw("dist"), "distributor_txn_id", _rules(ctx)["patterns"]["distributor_txn_id"], "distributor_txn_id")


@qa_check("DST-005", suite=D_SET, module=D_MOD, category="Data type", severity="High", dataset=DIST,
          title="Date / datetime fields are valid", requires=["dist"])
def dst_dates_valid(ctx):
    return v.valid_types(ctx.raw("dist"), ctx.invalid("dist"), ["sale_date", "created_at", "updated_at"], "distributor_txn_id", "date/time")


@qa_check("DST-006", suite=D_SET, module=D_MOD, category="Data type", severity="Critical", dataset=DIST,
          title="gross_amount / commission_amount are numeric", requires=["dist"])
def dst_amount_numeric(ctx):
    return v.valid_types(ctx.raw("dist"), ctx.invalid("dist"), ["gross_amount", "commission_amount"], "distributor_txn_id", "decimal number")


@qa_check("DST-007", suite=D_SET, module=D_MOD, category="Business rule", severity="Critical", dataset=DIST,
          title="gross_amount > 0 and 0 <= commission_amount <= gross_amount", requires=["dist"])
def dst_amount_rules(ctx):
    t, raw = ctx.typed("dist"), ctx.raw("dist")
    df = raw.assign(_g=t["gross_amount"], _c=t["commission_amount"])
    return v.multi_rule(df, [
        (df["_g"] <= 0, "gross_amount must be > 0", ["gross_amount"]),
        (df["_c"] < 0, "commission_amount must be >= 0", ["commission_amount"]),
        (df["_c"] > df["_g"], "commission_amount exceeds gross_amount", ["gross_amount", "commission_amount"]),
    ], "distributor_txn_id")


@qa_check("DST-008", suite=D_SET, module=D_MOD, category="Domain", severity="High", dataset=DIST,
          title="status is one of APPROVED / REJECTED / CANCELLED", requires=["dist"])
def dst_status(ctx):
    return v.domain(ctx.raw("dist"), "status", _rules(ctx)["domains"]["status"], "distributor_txn_id", allow_blank=False)


@qa_check("DST-009", suite=D_SET, module=D_MOD, category="Domain", severity="High", dataset=DIST,
          title="product_type_raw is a recognised product type", requires=["dist"])
def dst_product_type(ctx):
    return v.domain(ctx.raw("dist"), "product_type_raw", _rules(ctx)["domains"]["product_type_raw"], "distributor_txn_id", allow_blank=False)


@qa_check("DST-010", suite=D_SET, module=D_MOD, category="Domain", severity="Medium", dataset=DIST,
          title="region_code (when populated) is a valid region", requires=["dist"])
def dst_region(ctx):
    return v.domain(ctx.raw("dist"), "region_code", _rules(ctx)["domains"]["region_code"], "distributor_txn_id")


@qa_check("DST-011", suite=D_SET, module=D_MOD, category="Temporal", severity="Medium", dataset=DIST,
          title="updated_at >= created_at", requires=["dist"])
def dst_updated_after_created(ctx):
    t, raw = ctx.typed("dist"), ctx.raw("dist")
    df = raw.assign(_c=t["created_at"], _u=t["updated_at"])
    return v.rows_outcome(df, df["_u"] < df["_c"], "distributor_txn_id", ["created_at", "updated_at"], "updated_at earlier than created_at")


@qa_check("DST-012", suite=D_SET, module=D_MOD, category="Format", severity="Medium", dataset=DIST,
          title="customer_id (when populated) follows format CUST + digits", requires=["dist"])
def dst_customer_format(ctx):
    return v.pattern(ctx.raw("dist"), "customer_id", _rules(ctx)["patterns"]["dist_customer_id"], "distributor_txn_id")


@qa_check("DST-013", suite=D_SET, module=D_MOD, category="Format", severity="Medium", dataset=DIST,
          title="customer_pan (when populated) is a valid PAN", requires=["dist"])
def dst_pan_format(ctx):
    return v.pattern(ctx.raw("dist"), "customer_pan", _rules(ctx)["patterns"]["pan"], "distributor_txn_id")


@qa_check("DST-014", suite=D_SET, module=D_MOD, category="Data truncation", severity="Medium", dataset=DIST,
          title="Text values fit DDL column lengths", requires=["dist"])
def dst_lengths(ctx):
    return v.lengths(ctx.raw("dist"), ctx.schema("dist"), "distributor_txn_id")


@qa_check("DST-015", suite=D_SET, module=D_MOD, category="Completeness", severity="Medium", dataset=DIST,
          title="Optional columns are not excessively blank (distributor_name, customer_id, PAN, region)", requires=["dist"])
def dst_blank_rate(ctx):
    """Nullable per DDL, but a high blank-rate indicates a feed/extract defect."""
    return v.blank_rate(ctx.raw("dist"), ctx.thresholds["optional_blank_max_pct"]["dist"], "distributor_txn_id")


@qa_check("DST-016", suite=D_SET, module=D_MOD, category="Temporal", severity="Medium", dataset=DIST,
          title="sale_date is within a plausible window (not in future / before min date)", requires=["dist"])
def dst_sale_window(ctx):
    t, raw = ctx.typed("dist"), ctx.raw("dist")
    df = raw.assign(_d=t["sale_date"])
    lo = pd.Timestamp(ctx.thresholds["min_sale_date"])
    return v.rows_outcome(df, (df["_d"] < lo) | (df["_d"] > pd.Timestamp.now()), "distributor_txn_id", "sale_date",
                          f"sale_date earlier than {lo.date()} or in the future")


@qa_check("DST-017", suite=D_SET, module=D_MOD, category="Format", severity="Low", dataset=DIST,
          title="No leading/trailing whitespace in values", requires=["dist"])
def dst_whitespace(ctx):
    return v.whitespace(ctx.raw("dist"), "distributor_txn_id")


@qa_check("DST-018", suite=D_SET, module=D_MOD, category="Format", severity="High", dataset=DIST,
          title="product_code follows format (MF|INS)_<code>", requires=["dist"])
def dst_product_code(ctx):
    return v.pattern(ctx.raw("dist"), "product_code", _rules(ctx)["patterns"]["product_code"], "distributor_txn_id", allow_blank=False)


# ================================ FACT SALES ================================
@qa_check("FAC-001", suite=F_SET, module=F_MOD, category="Completeness", severity="Critical", dataset=FACT,
          title="Mandatory (NOT NULL) fields are populated", requires=["fact"])
def fac_mandatory(ctx):
    return v.mandatory(ctx.raw("fact"), ctx.schema("fact"), "sales_sk")


@qa_check("FAC-002", suite=F_SET, module=F_MOD, category="Uniqueness", severity="Critical", dataset=FACT,
          title="sales_sk (surrogate key) is unique", requires=["fact"])
def fac_sk_unique(ctx):
    return v.unique(ctx.raw("fact"), "sales_sk", ["distributor_txn_id"], "sales_sk")


@qa_check("FAC-003", suite=F_SET, module=F_MOD, category="Uniqueness", severity="Critical", dataset=FACT,
          title="distributor_txn_id is unique (no duplicate transactions)", requires=["fact"])
def fac_txn_unique(ctx):
    return v.unique(ctx.raw("fact"), "distributor_txn_id", ["sales_sk", "policy_number", "gross_amount"], "distributor_txn_id")


@qa_check("FAC-004", suite=F_SET, module=F_MOD, category="Uniqueness", severity="High", dataset=FACT,
          title="policy_number is unique", requires=["fact"])
def fac_policy_unique(ctx):
    return v.unique(ctx.raw("fact"), "policy_number", ["sales_sk", "distributor_txn_id"], "policy_number")


@qa_check("FAC-005", suite=F_SET, module=F_MOD, category="Data type", severity="Critical", dataset=FACT,
          title="Numeric / integer fields are valid numbers", requires=["fact"])
def fac_numeric(ctx):
    cols = [c["name"] for c in ctx.schema("fact")["columns"] if c["type"] in ("int", "decimal")]
    return v.valid_types(ctx.raw("fact"), ctx.invalid("fact"), cols, "sales_sk", "number")


@qa_check("FAC-006", suite=F_SET, module=F_MOD, category="Business rule", severity="Critical", dataset=FACT,
          title="Amount rules: gross>0, net/tax/discount>=0, 0<=commission<=gross, 0<=commission_pct<=15, txn_count=1", requires=["fact"])
def fac_amount_rules(ctx):
    """Mirrors the CHECK constraints in the Fact_Sales DDL."""
    t, raw = ctx.typed("fact"), ctx.raw("fact")
    mx = ctx.thresholds["commission_pct_max"]
    df = raw.copy()
    for c in ["gross_amount", "net_amount", "tax_amount", "discount_amount", "commission_amount", "commission_pct", "txn_count"]:
        df["_" + c] = t[c]
    return v.multi_rule(df, [
        (df["_gross_amount"] <= 0, "gross_amount must be > 0", ["gross_amount"]),
        (df["_net_amount"] < 0, "net_amount must be >= 0", ["net_amount"]),
        (df["_tax_amount"] < 0, "tax_amount must be >= 0", ["tax_amount"]),
        (df["_discount_amount"] < 0, "discount_amount must be >= 0", ["discount_amount"]),
        (df["_commission_amount"] < 0, "commission_amount must be >= 0", ["commission_amount"]),
        (df["_commission_amount"] > df["_gross_amount"], "commission_amount exceeds gross_amount", ["gross_amount", "commission_amount"]),
        ((df["_commission_pct"] < 0) | (df["_commission_pct"] > mx), f"commission_pct outside 0..{mx}", ["commission_pct"]),
        (df["_txn_count"].ne(1), "txn_count must equal 1", ["txn_count"]),
    ], "sales_sk")


@qa_check("FAC-007", suite=F_SET, module=F_MOD, category="Domain", severity="Medium", dataset=FACT,
          title="Flags (is_new_customer_flag, is_high_value_flag) are Y/N", requires=["fact"])
def fac_flags(ctx):
    raw = ctx.raw("fact")
    yn = _rules(ctx)["domains"]["yn"]
    bad = ~raw["is_new_customer_flag"].isin(yn) | ~raw["is_high_value_flag"].isin(yn)
    return v.rows_outcome(raw, bad, "sales_sk", ["is_new_customer_flag", "is_high_value_flag"], "Flag value not in Y/N")


@qa_check("FAC-008", suite=F_SET, module=F_MOD, category="Domain", severity="High", dataset=FACT,
          title="status is one of APPROVED / REJECTED / CANCELLED", requires=["fact"])
def fac_status(ctx):
    return v.domain(ctx.raw("fact"), "status", _rules(ctx)["domains"]["status"], "sales_sk", allow_blank=False)


@qa_check("FAC-009", suite=F_SET, module=F_MOD, category="Temporal", severity="Medium", dataset=FACT,
          title="Datetime fields valid and src_updated_at >= src_created_at", requires=["fact"])
def fac_datetimes(ctx):
    raw, t, inv = ctx.raw("fact"), ctx.typed("fact"), ctx.invalid("fact")
    cols = ["src_created_at", "src_updated_at", "etl_load_ts_utc"]
    bad_fmt = inv[cols].any(axis=1)
    df = raw.assign(_c=t["src_created_at"], _u=t["src_updated_at"])
    return v.multi_rule(df, [
        (bad_fmt, "Unparseable datetime value", cols),
        (df["_u"] < df["_c"], "src_updated_at earlier than src_created_at", ["src_created_at", "src_updated_at"]),
    ], "sales_sk")


@qa_check("FAC-010", suite=F_SET, module=F_MOD, category="Format", severity="High", dataset=FACT,
          title="sale_date_key is a valid yyyymmdd date", requires=["fact"])
def fac_date_key(ctx):
    raw = ctx.raw("fact")
    parsed = pd.to_datetime(raw["sale_date_key"].str.strip(), format="%Y%m%d", errors="coerce")
    return v.rows_outcome(raw, parsed.isna() | ~raw["sale_date_key"].str.fullmatch(r"\d{8}"), "sales_sk", "sale_date_key",
                          "sale_date_key is not a valid yyyymmdd date")


@qa_check("FAC-011", suite=F_SET, module=F_MOD, category="Data truncation", severity="Medium", dataset=FACT,
          title="Text values fit DDL column lengths", requires=["fact"])
def fac_lengths(ctx):
    return v.lengths(ctx.raw("fact"), ctx.schema("fact"), "sales_sk")


@qa_check("FAC-012", suite=F_SET, module=F_MOD, category="Completeness", severity="High", dataset=FACT,
          title="customer_key is populated (blank-rate within tolerance)", requires=["fact"])
def fac_blank_rate(ctx):
    """Sales without a customer_key cannot be linked to the Customer Master."""
    return v.blank_rate(ctx.raw("fact"), ctx.thresholds["optional_blank_max_pct"]["fact"], "sales_sk")
