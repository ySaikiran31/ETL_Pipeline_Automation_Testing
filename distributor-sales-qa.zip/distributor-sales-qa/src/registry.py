"""Check registry. Every validation is a function decorated with @qa_check.

The same registry drives BOTH execution modes:
    * ``python run_qa.py``   (stand-alone runner)
    * ``pytest``             (parametrised tests)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Sequence

CHECKS: Dict[str, "CheckSpec"] = {}


@dataclass
class CheckSpec:
    test_id: str
    func: Callable
    suite: str
    module: str
    title: str
    category: str
    severity: str
    dataset: str
    defect_area: str
    requires: Sequence[str] = field(default_factory=tuple)   # "dist","fact","cust" (files) / "db:dist" ... / "db"
    description: str = ""


def qa_check(test_id: str, *, suite: str, module: str, title: str, category: str,
             severity: str = "High", dataset: str = "", defect_area: str = "Source data",
             requires: Sequence[str] = ()):
    def deco(fn: Callable) -> Callable:
        if test_id in CHECKS:
            raise ValueError(f"Duplicate test id {test_id}")
        CHECKS[test_id] = CheckSpec(test_id, fn, suite, module, title, category, severity,
                                    dataset, defect_area, tuple(requires), (fn.__doc__ or "").strip())
        return fn
    return deco


def load_all_checks() -> Dict[str, CheckSpec]:
    """Import every check module (decorators register on import)."""
    from src import (file_reader, sales_validator, customer_validator, database,  # noqa: F401
                     reconciliation, business_rules, datamart_validator)
    return CHECKS


def checks_for(suite: str) -> List[CheckSpec]:
    load_all_checks()
    return sorted((c for c in CHECKS.values() if c.suite == suite), key=lambda c: c.test_id)
