"""Result model: statuses, Outcome (returned by checks) and CheckResult (reported)."""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Optional

import pandas as pd

PASS, FAIL, ERROR, SKIPPED = "PASS", "FAIL", "ERROR", "SKIPPED"
SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}


class PrerequisiteError(Exception):
    """A dataset/database a check depends on is unavailable -> check is SKIPPED."""


@dataclass
class Outcome:
    """What a check function returns."""
    total: int = 0
    failed: Optional[pd.DataFrame] = None   # offending records = evidence
    message: str = ""
    skipped: bool = False
    failed_total: Optional[int] = None      # true count when `failed` is only a capped sample

    @property
    def failed_count(self) -> int:
        if self.failed_total is not None:
            return self.failed_total
        return 0 if self.failed is None else len(self.failed)

    @classmethod
    def skip(cls, reason: str) -> "Outcome":
        return cls(message=reason, skipped=True)

    @classmethod
    def from_bool(cls, ok: bool, ok_msg: str, fail_msg: str, evidence: dict | None = None) -> "Outcome":
        if ok:
            return cls(total=1, message=ok_msg)
        return cls(total=1, message=fail_msg, failed=pd.DataFrame([evidence or {"detail": fail_msg}]))


@dataclass
class CheckResult:
    test_id: str
    module: str
    suite: str
    title: str
    category: str
    severity: str
    dataset: str
    defect_area: str
    status: str
    total_records: int
    failed_records: int
    message: str
    evidence_file: str = ""
    duration_sec: float = 0.0
    executed_at: str = ""
    known_defect: str = ""

    def as_dict(self) -> dict:
        return asdict(self)
