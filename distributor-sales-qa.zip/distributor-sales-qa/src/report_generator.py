"""Report Generator: PASS/FAIL results, defect log, reconciliation report, HTML executive summary, Excel workbook."""
from __future__ import annotations

import html
import json
import platform
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import pandas as pd

from src.logger import get_logger
from src.registry import CheckSpec
from src.results import ERROR, FAIL, PASS, SEVERITY_ORDER, SKIPPED, CheckResult

log = get_logger("report")

OWNER = {"Source data": "Source/Distributor feed owner", "Customer Master": "Customer Master data owner",
         "Mapping/Reference": "ETL / Data-mapping owner", "Target (data mart)": "ETL developer (data mart)",
         "Database": "DBA / ETL developer", "Database (load)": "ETL developer (source load)",
         "Environment/configuration": "QA / Environment support", "Automation": "QA automation"}

METRICS = [  # (label, predicate on CheckResult)
    ("Missing / extra records", lambda r: "Missing" in r.category or "Extra" in r.category or r.test_id in ("DBQ-011", "DBQ-012")),
    ("Duplicate records", lambda r: r.category == "Uniqueness"),
    ("Customer validation failures", lambda r: r.module in ("Customer Master Validation", "Customer Reference Validation") or r.test_id in ("DM-007", "DBQ-013", "DM-012")),
    ("Product validation failures", lambda r: r.module == "Product & Product Family Validation" or r.test_id == "DM-003"),
    ("Calculation failures", lambda r: r.module == "Monetary Calculation Validation"),
    ("Source-to-target mismatches", lambda r: r.suite == "reconciliation" and r.category != "Missing / extra records"),
    ("Business-rule violations", lambda r: r.category in ("Business rule", "Derived flag", "Derived value")),
]


# ------------------------------------------------------------------ summaries
def summarize(results: List[CheckResult]) -> Dict:
    df = pd.DataFrame([r.as_dict() for r in results])
    counts = df["status"].value_counts().to_dict()
    by_module = (df.pivot_table(index="module", columns="status", values="test_id", aggfunc="count", fill_value=0)
                 .reindex(columns=[PASS, FAIL, ERROR, SKIPPED], fill_value=0))
    by_module.insert(0, "Total", by_module.sum(axis=1))
    order = list(dict.fromkeys(df["module"]))
    by_module = by_module.reindex(order)
    new_fail = [r for r in results if r.status in (FAIL, ERROR) and not r.known_defect]
    overall = "FAIL" if any(r.status in (FAIL, ERROR) for r in results) else "PASS"
    metrics = []
    for label, pred in METRICS:
        sel = [r for r in results if pred(r)]
        metrics.append({"metric": label, "checks_executed": sum(r.status != SKIPPED for r in sel),
                        "checks_failed": sum(r.status in (FAIL, ERROR) for r in sel),
                        "failing_records": sum(r.failed_records for r in sel if r.status == FAIL)})
    return {"counts": {s: int(counts.get(s, 0)) for s in (PASS, FAIL, ERROR, SKIPPED)}, "total": len(results), "by_module": by_module,
            "overall": overall, "new_failures": len(new_fail), "metrics": pd.DataFrame(metrics),
            "by_severity": pd.Series([r.severity for r in results if r.status in (FAIL, ERROR)]).value_counts().reindex(list(SEVERITY_ORDER), fill_value=0)}


def defect_log(results: List[CheckResult], evidence_dir: Path) -> pd.DataFrame:
    bad = sorted((r for r in results if r.status in (FAIL, ERROR)), key=lambda r: (SEVERITY_ORDER.get(r.severity, 9), r.test_id))
    rows = []
    for i, r in enumerate(bad, 1):
        sample = ""
        if r.evidence_file:
            ev = evidence_dir / Path(r.evidence_file.split(" (")[0]).name
            if ev.exists():
                head = pd.read_csv(ev, nrows=2, dtype=str, encoding="utf-8-sig").fillna("")
                sample = " || ".join("; ".join(f"{k}={v}" for k, v in row.items() if k != "failure_reason") for row in head.to_dict("records"))[:500]
        rows.append({"defect_id": f"DEF-{i:03d}", "test_id": r.test_id, "severity": r.severity, "status": "Open",
                     "result": r.status, "module": r.module, "validation": r.title, "dataset": r.dataset,
                     "probable_root_cause_area": r.defect_area if r.status == FAIL else "Automation / environment",
                     "suggested_owner": OWNER.get(r.defect_area, "QA lead") if r.status == FAIL else OWNER["Automation"],
                     "failed_records": r.failed_records, "total_records": r.total_records,
                     "failure_reason": r.message, "sample_evidence": sample, "evidence_file": r.evidence_file,
                     "known_defect_ref": r.known_defect, "reproduce": f"python run_qa.py --only {r.test_id}"})
    return pd.DataFrame(rows)


def reconciliation_report(results: List[CheckResult]) -> pd.DataFrame:
    rows = [{"test_id": r.test_id, "reconciliation": r.title, "category": r.category, "dataset": r.dataset, "compared": r.total_records,
             "matched": max(r.total_records - r.failed_records, 0) if r.status in (PASS, FAIL) else "", "mismatched_or_missing": r.failed_records,
             "status": r.status, "detail": r.message}
            for r in results if r.suite == "reconciliation" or r.category == "Reconciliation"]
    return pd.DataFrame(rows)


def inventory(specs: List[CheckSpec]) -> pd.DataFrame:
    return pd.DataFrame([{"test_id": s.test_id, "module": s.module, "suite": s.suite, "scenario": s.title, "validation_type": s.category,
                          "priority": s.severity, "data_source": s.dataset, "preconditions": ", ".join(s.requires) or "none",
                          "automation_status": "Automated", "evidence": "Failed-record CSV in reports/evidence/", "implementation": s.description}
                         for s in sorted(specs, key=lambda x: x.test_id)])


# ------------------------------------------------------------------ writers
def write_reports(results: List[CheckResult], specs: List[CheckSpec], reports_dir: Path, profile: Dict, meta: Dict, archive: bool = True) -> Dict[str, Path]:
    reports_dir.mkdir(parents=True, exist_ok=True)
    ev_dir = reports_dir / "evidence"
    s = summarize(results)
    out = {}
    res_df = pd.DataFrame([r.as_dict() for r in results])
    out["validation_results"] = reports_dir / "validation_results.csv"
    res_df.to_csv(out["validation_results"], index=False, encoding="utf-8-sig")
    dl = defect_log(results, ev_dir)
    out["defect_log"] = reports_dir / "defect_log.csv"
    dl.to_csv(out["defect_log"], index=False, encoding="utf-8-sig")
    rec = reconciliation_report(results)
    out["reconciliation_report"] = reports_dir / "reconciliation_report.csv"
    rec.to_csv(out["reconciliation_report"], index=False, encoding="utf-8-sig")
    inv = inventory(specs)
    out["test_case_inventory"] = reports_dir / "test_case_inventory.csv"
    inv.to_csv(out["test_case_inventory"], index=False, encoding="utf-8-sig")
    out["qa_summary"] = reports_dir / "qa_summary.html"
    out["qa_summary"].write_text(render_html(results, s, dl, profile, meta), encoding="utf-8")
    try:
        out["qa_report_xlsx"] = reports_dir / "qa_report.xlsx"
        with pd.ExcelWriter(out["qa_report_xlsx"], engine="openpyxl") as xw:
            pd.DataFrame({"Metric": ["Overall status", "Validations executed", "PASS", "FAIL", "ERROR", "SKIPPED", *[f"Severity {k} (failed)" for k in s["by_severity"].index]],
                          "Value": [s["overall"], s["total"], *s["counts"].values(), *s["by_severity"].values]}).to_excel(xw, sheet_name="Summary", index=False)
            s["by_module"].reset_index().to_excel(xw, sheet_name="By module", index=False)
            s["metrics"].to_excel(xw, sheet_name="QA metrics", index=False)
            res_df.to_excel(xw, sheet_name="Results", index=False)
            dl.to_excel(xw, sheet_name="Defect log", index=False)
            rec.to_excel(xw, sheet_name="Reconciliation", index=False)
            inv.to_excel(xw, sheet_name="Test case inventory", index=False)
            for name, ws in xw.sheets.items():
                ws.freeze_panes = "A2"
                for col in ws.columns:
                    ws.column_dimensions[col[0].column_letter].width = min(60, max(12, max(len(str(c.value or "")) for c in col[:50]) + 2))
    except Exception as exc:  # noqa: BLE001 - Excel is optional
        log.warning("Excel report skipped: %s", exc)
        out.pop("qa_report_xlsx", None)
    (reports_dir / "run_metadata.json").write_text(json.dumps({**meta, "counts": s["counts"], "overall": s["overall"], "data_profile": profile}, indent=2, default=str))
    if archive:
        arc = reports_dir / "archive" / meta["run_id"]
        arc.mkdir(parents=True, exist_ok=True)
        for p in list(out.values()) + [reports_dir / "run_metadata.json"]:
            shutil.copy2(p, arc / p.name)
        if ev_dir.exists():
            shutil.copytree(ev_dir, arc / "evidence", dirs_exist_ok=True)
    log.info("Reports written to %s", reports_dir)
    return out


# ------------------------------------------------------------------ HTML
CSS = """
:root{--bg:#f6f7f9;--card:#fff;--ink:#1d2433;--mut:#667085;--line:#e4e7ec;--pass:#127a3d;--passbg:#e3f6ea;--fail:#b42318;--failbg:#fde8e6;--err:#93370d;--errbg:#fef0c7;--skip:#475467;--skipbg:#eaecf0;--acc:#1f4fd8}
@media(prefers-color-scheme:dark){:root{--bg:#10141c;--card:#171c27;--ink:#e6e9f0;--mut:#98a2b3;--line:#2a3243;--passbg:#0f3a22;--pass:#6ee7a0;--failbg:#4a1713;--fail:#ff9b92;--errbg:#4a3208;--err:#fbc86b;--skipbg:#262d3b;--skip:#b7c0d0;--acc:#7da2ff}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}
.wrap{max-width:1240px;margin:0 auto;padding:28px 20px 60px}h1{font-size:24px;margin:0 0 4px}h2{font-size:17px;margin:34px 0 10px}.mut{color:var(--mut)}
.banner{display:flex;align-items:center;gap:16px;padding:18px 20px;border-radius:12px;margin:18px 0;border:1px solid var(--line);background:var(--card)}
.big{font-size:22px;font-weight:700;padding:6px 18px;border-radius:8px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:14px 0}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}.kpi b{display:block;font-size:24px}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden;font-size:13px}
th,td{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{background:var(--bg);font-weight:600;position:sticky;top:0}
td.n{text-align:right;font-variant-numeric:tabular-nums}.scroll{overflow-x:auto}
.chip{display:inline-block;padding:1px 9px;border-radius:99px;font-weight:600;font-size:12px}
.PASS{background:var(--passbg);color:var(--pass)}.FAIL{background:var(--failbg);color:var(--fail)}.ERROR{background:var(--errbg);color:var(--err)}.SKIPPED{background:var(--skipbg);color:var(--skip)}
.sev-Critical{color:var(--fail);font-weight:700}.sev-High{color:var(--err);font-weight:600}
.filters button{border:1px solid var(--line);background:var(--card);color:var(--ink);padding:4px 12px;border-radius:99px;cursor:pointer;margin-right:6px}
.filters button.on{background:var(--acc);color:#fff;border-color:var(--acc)}a{color:var(--acc)}code{font-size:12px}
"""


def _evidence_link(r) -> str:
    if not r.evidence_file:
        return ""
    return '<a href="' + html.escape(r.evidence_file.split(" (")[0]) + '">evidence</a>'


def _chip(s):
    return f'<span class="chip {s}">{s}</span>'


def render_html(results: List[CheckResult], s: Dict, dl: pd.DataFrame, profile: Dict, meta: Dict) -> str:
    e = html.escape
    c = s["counts"]
    ov = s["overall"]
    kp = "".join(f'<div class="kpi"><span class="mut">{k}</span><b>{v}</b></div>' for k, v in
                 [("Validations executed", s["total"]), ("PASS", c[PASS]), ("FAIL", c[FAIL]), ("ERROR", c[ERROR]), ("SKIPPED / blocked", c[SKIPPED]),
                  ("Critical failures", int(s["by_severity"]["Critical"])), ("High failures", int(s["by_severity"]["High"]))])
    prof = "".join(f"<tr><td>{e(k)}</td><td class='n'>{v:,}</td></tr>" for k, v in profile.items())
    mod = "".join(f"<tr><td>{e(i)}</td><td class='n'>{r['Total']}</td><td class='n'>{r[PASS]}</td><td class='n'>{r[FAIL]}</td><td class='n'>{r[ERROR]}</td><td class='n'>{r[SKIPPED]}</td></tr>"
                  for i, r in s["by_module"].iterrows())
    met = "".join(f"<tr><td>{e(r.metric)}</td><td class='n'>{r.checks_executed}</td><td class='n'>{r.checks_failed}</td><td class='n'>{r.failing_records:,}</td></tr>" for r in s["metrics"].itertuples())
    defects = "".join(
        f"<tr><td>{e(r.defect_id)}</td><td>{e(r.test_id)}</td><td class='sev-{r.severity}'>{r.severity}</td><td>{e(r.validation)}</td>"
        f"<td class='n'>{r.failed_records:,}</td><td>{e(r.failure_reason)}</td><td>{e(r.probable_root_cause_area)}</td></tr>" for r in dl.itertuples())
    rows = "".join(
        f"<tr data-s='{r.status}'><td>{r.test_id}</td><td>{e(r.module)}</td><td>{e(r.title)}</td><td class='sev-{r.severity}'>{r.severity}</td><td>{_chip(r.status)}</td>"
        f"<td class='n'>{r.total_records:,}</td><td class='n'>{r.failed_records:,}</td><td>{e(r.message[:400])}</td>"
        f"<td>{_evidence_link(r)}</td></tr>" for r in results)
    skipped = [r for r in results if r.status == SKIPPED]
    cov = f"<p class='mut'>{len(skipped)} validation(s) were SKIPPED/BLOCKED (prerequisite unavailable or not evaluable) - they are <b>not</b> counted as PASS.</p>" if skipped else ""
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>QA Reconciliation Report</title><style>{CSS}</style></head><body><div class="wrap">
<h1>Distributor Sales Data Reconciliation - QA Summary</h1>
<div class="mut">Run <b>{e(meta['run_id'])}</b> &middot; {e(meta['started'])} &middot; Environment: {e(meta['environment'])} &middot; DB: {e(meta['database'])} &middot; Python {e(meta['python'])}</div>
<div class="banner"><span class="big {'PASS' if ov == 'PASS' else 'FAIL'}">OVERALL: {ov}</span>
<div>{c[PASS]} of {s['total']} validations passed; <b>{c[FAIL] + c[ERROR]}</b> failed/errored ({s['new_failures']} not previously known). Duration {meta['duration_sec']}s.</div></div>
<div class="kpis">{kp}</div>{cov}
<h2>Data processed</h2><table style="max-width:420px"><tr><th>Dataset</th><th>Records</th></tr>{prof}</table>
<h2>Results by validation module</h2><div class="scroll"><table><tr><th>Module</th><th>Total</th><th>PASS</th><th>FAIL</th><th>ERROR</th><th>SKIPPED</th></tr>{mod}</table></div>
<h2>QA metrics</h2><div class="scroll"><table style="max-width:700px"><tr><th>Metric</th><th>Checks executed</th><th>Checks failed</th><th>Failing records</th></tr>{met}</table></div>
<h2>Defect log (ordered by severity)</h2><div class="scroll"><table><tr><th>ID</th><th>Test</th><th>Severity</th><th>Validation</th><th>Failed</th><th>Finding</th><th>Root-cause area</th></tr>{defects or '<tr><td colspan=7>No defects.</td></tr>'}</table></div>
<h2>All validation results</h2><div class="filters"><button class="on" data-f="ALL">All</button><button data-f="FAIL">FAIL</button><button data-f="ERROR">ERROR</button><button data-f="SKIPPED">SKIPPED</button><button data-f="PASS">PASS</button></div><br>
<div class="scroll"><table id="t"><tr><th>ID</th><th>Module</th><th>Validation</th><th>Severity</th><th>Result</th><th>Checked</th><th>Failed</th><th>Detail</th><th>Evidence</th></tr>{rows}</table></div>
<p class="mut">Failed-record evidence: <code>reports/evidence/&lt;TEST-ID&gt;.csv</code> &middot; Defect log: <code>defect_log.csv</code> &middot; Reconciliation: <code>reconciliation_report.csv</code></p>
</div><script>document.querySelectorAll('.filters button').forEach(b=>b.onclick=()=>{{document.querySelectorAll('.filters button').forEach(x=>x.classList.remove('on'));b.classList.add('on');
document.querySelectorAll('#t tr[data-s]').forEach(r=>r.style.display=(b.dataset.f==='ALL'||r.dataset.s===b.dataset.f)?'':'none')}})</script></body></html>"""


def build_meta(run_id: str, started: datetime, duration: float, settings) -> Dict:
    db = settings.db
    return {"run_id": run_id, "started": started.strftime("%Y-%m-%d %H:%M:%S"), "duration_sec": round(duration, 1),
            "environment": settings.cfg["project"]["environment"], "database": f"{db['host']}:{db['port']}/{db['name']}",
            "python": platform.python_version(), "platform": platform.platform()}
