"""Reconciliation module: comparison engine + source-to-target reconciliation checks.

    REC-001..012  source files  <->  MySQL source tables, and cross-source (Distributor vs Fact)
    REC-020..026  source files  ->   target data mart dm_Distributor_Sales_Customer_360
"""
from __future__ import annotations

from typing import Dict, List, Sequence

import numpy as np
import pandas as pd

from src.normalizer import coerce_typed
from src.registry import qa_check
from src.results import Outcome

SET = "reconciliation"
MOD_L, MOD_X, MOD_T = "Source-to-Source Load Reconciliation", "Cross-Source Reconciliation", "Source-to-Target (Data Mart) Reconciliation"
NAMES = {"dist": "dim_Distributor_sales", "fact": "Fact_Sales", "cust": "dim_Customer_Master"}


# ============================== comparison engine ============================
def _fmt(s: pd.Series) -> pd.Series:
    return s.astype(object).where(s.notna(), "<NULL>").astype(str)


def compare_frames(src: pd.DataFrame, tgt: pd.DataFrame, key: Sequence[str] | str, columns: Sequence[str]) -> Dict:
    """Full-outer reconciliation on `key`. Both frames must already be normalised/typed.

    Returns dict(missing, extra, mismatches, matched_keys, compared_keys, dup_source, dup_target)
    """
    key = [key] if isinstance(key, str) else list(key)
    columns = [c for c in columns if c in src.columns and c in tgt.columns and c not in key]
    dup_s, dup_t = int(src.duplicated(key).sum()), int(tgt.duplicated(key).sum())
    s = src.drop_duplicates(key)[key + columns]
    t = tgt.drop_duplicates(key)[key + columns]
    m = s.merge(t, on=key, how="outer", suffixes=("__s", "__t"), indicator=True)
    missing = m.loc[m["_merge"] == "left_only", key].reset_index(drop=True)
    extra = m.loc[m["_merge"] == "right_only", key].reset_index(drop=True)
    both = m[m["_merge"] == "both"]
    parts, bad_keys = [], pd.Series(False, index=both.index)
    for c in columns:
        a, b = both[f"{c}__s"], both[f"{c}__t"]
        eq = (a == b).fillna(False).astype(bool) | (a.isna() & b.isna())
        neq = ~eq
        if neq.any():
            e = both.loc[neq, key].copy()
            e["column"], e["source_value"], e["target_value"] = c, _fmt(a[neq]), _fmt(b[neq])
            e["failure_reason"] = f"Value mismatch in {c}"
            parts.append(e)
            bad_keys |= neq
    mism = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=key + ["column", "source_value", "target_value", "failure_reason"])
    return {"missing": missing, "extra": extra, "mismatches": mism, "compared_keys": len(both),
            "matched_keys": int((~bad_keys).sum()), "compared_columns": len(columns), "dup_source": dup_s, "dup_target": dup_t}


def mismatch_outcome(res: Dict, what: str) -> Outcome:
    mism = res["mismatches"]
    total = res["compared_keys"] * max(res["compared_columns"], 1)
    if mism.empty:
        return Outcome(total=total, message=f"{res['compared_keys']:,} records x {res['compared_columns']} columns compared - all match")
    by_col = mism["column"].value_counts().to_dict()
    return Outcome(total=total, failed=mism,
                   message=f"{len(mism):,} field mismatches in {mism.iloc[:, 0].nunique():,} of {res['compared_keys']:,} records ({what}); by column: {by_col}")


def _key_outcome(df: pd.DataFrame, key: str, total: int, reason: str, ok: str) -> Outcome:
    if df.empty:
        return Outcome(total=total, message=ok)
    ev = df.copy()
    ev["failure_reason"] = reason
    return Outcome(total=total, failed=ev, message=f"{len(ev):,} record(s): {reason}")


# ============================ expected data mart =============================
DM_AUDIT = {"dm_sk", "dm_etl_run_id", "dm_load_ts_utc"}
FACT_COLS = ["sales_sk", "policy_number", "sale_date_key", "region_key", "status", "gross_amount", "net_amount", "commission_amount",
             "tax_amount", "discount_amount", "premium_amount", "sum_assured", "units_allocated", "nav_at_purchase", "commission_pct",
             "txn_count", "is_new_customer_flag", "is_high_value_flag", "src_created_at", "src_updated_at", "fact_etl_run_id"]
DIST_COLS = ["customer_id", "sale_date", "distributor_code", "distributor_name", "product_code", "product_name_raw", "product_type_raw",
             "product_family", "product_category", "folio_number", "region_code", "is_ins_txn_flag", "is_mf_txn_flag"]
CUST_COLS = ["customer_key", "customer_pan", "first_name", "last_name", "gender", "date_of_birth", "customer_age", "email", "mobile", "city",
             "state", "pincode", "country", "kyc_status", "customer_segment", "annual_income", "customer_onboarded_on",
             "customer_active_flag", "is_kyc_verified_flag"]


def build_expected_dm(fact: pd.DataFrame, dist: pd.DataFrame, cust: pd.DataFrame, approved_status: str = "APPROVED") -> pd.DataFrame:
    """Independent re-implementation of the documented data-mart transformation (03_load_datamart.sql),
    computed from the SOURCE FILES with pandas."""
    f = fact[fact["status"] == approved_status].rename(columns={"etl_run_id": "fact_etl_run_id"})
    f = f[["distributor_txn_id"] + FACT_COLS_RAW(f)]
    d = dist[["distributor_txn_id", "policy_number", "customer_id", "sale_date", "distributor_code", "distributor_name", "product_code",
              "product_name_raw", "product_type_raw", "folio_number", "region_code"]].rename(columns={"customer_id": "d_customer_id"})
    x = f.merge(d, on=["distributor_txn_id", "policy_number"], how="inner", suffixes=("", "_d"))
    c = cust[["customer_key", "customer_id", "customer_pan", "first_name", "last_name", "gender", "date_of_birth", "email", "mobile", "city",
              "state", "pincode", "country", "kyc_status", "customer_segment", "annual_income", "onboarded_on", "active_flag"]]
    c = c[c["customer_id"].notna()].rename(columns={"customer_id": "c_customer_id", "onboarded_on": "customer_onboarded_on",
                                                    "active_flag": "customer_active_flag"})
    x = x.merge(c, how="left", left_on="d_customer_id", right_on="c_customer_id")
    x = x.sort_values("sales_sk", kind="stable").reset_index(drop=True)

    code = x["product_code"].fillna("").str.upper()
    ptype = x["product_type_raw"].fillna("").str.upper()
    x["customer_id"] = x["d_customer_id"].where(x["d_customer_id"].notna(), x["c_customer_id"])
    x["product_family"] = np.where(code.str.startswith("INS"), "INS", "MF")
    x["product_category"] = np.where(ptype.isin(["INS", "INSURANCE", "ULIP"]), "INSURANCE", "MUTUAL_FUND")
    sd, dob = x["sale_date"], x["date_of_birth"]
    age = sd.dt.year - dob.dt.year - ((sd.dt.month < dob.dt.month) | ((sd.dt.month == dob.dt.month) & (sd.dt.day < dob.dt.day))).astype(int)
    x["customer_age"] = age.where(dob.notna())
    x["is_kyc_verified_flag"] = np.where(x["kyc_status"] == "VERIFIED", "Y", "N")
    x["is_ins_txn_flag"] = np.where(code.str.startswith("INS"), "Y", "N")
    x["is_mf_txn_flag"] = np.where(code.str.startswith("MF"), "Y", "N")
    x.insert(0, "dm_sk", np.arange(1, len(x) + 1))
    return x


def FACT_COLS_RAW(f: pd.DataFrame) -> List[str]:
    return [c for c in FACT_COLS if c in f.columns and c != "policy_number"] + ["policy_number"]


def expected_dm_typed(ctx) -> pd.DataFrame:
    return coerce_typed(ctx.expected_dm(), ctx.schema("dm"))


# ======================= A. file  <->  MySQL source tables ====================
def _register_load_checks(key: str, n_cnt: int, n_key: int, n_fld: int):
    pk = {"dist": "distributor_txn_id", "fact": "sales_sk", "cust": "customer_key"}[key]
    area = "Database (load)"
    ds = f"{NAMES[key]} (file vs table)"

    @qa_check(f"REC-{n_cnt:03d}", suite=SET, module=MOD_L, category="Record count", severity="Critical", dataset=ds, defect_area=area,
              title=f"{NAMES[key]}: file record count equals table row count", requires=[key, f"db:{key}"])
    def _count(ctx, key=key):
        f, t = len(ctx.raw(key)), len(ctx.db_raw(key))
        return Outcome.from_bool(f == t, f"File={f:,} Table={t:,}", f"Record count mismatch: file={f:,} table={t:,} (diff {t - f:+,})",
                                 {"file_rows": f, "table_rows": t, "failure_reason": "Count mismatch"})

    @qa_check(f"REC-{n_key:03d}", suite=SET, module=MOD_L, category="Missing / extra records", severity="Critical", dataset=ds, defect_area=area,
              title=f"{NAMES[key]}: no file records missing from, or extra in, the table (key {pk})", requires=[key, f"db:{key}"])
    def _keys(ctx, key=key, pk=pk):
        s, t = set(ctx.typed(key)[pk].dropna()), set(ctx.db_typed(key)[pk].dropna())
        miss, extra = sorted(s - t), sorted(t - s)
        rows = [{pk: k, "failure_reason": "In file but MISSING in table"} for k in miss] + \
               [{pk: k, "failure_reason": "In table but NOT in file (extra)"} for k in extra]
        total = len(s | t)
        if rows:
            return Outcome(total=total, failed=pd.DataFrame(rows), message=f"{len(miss):,} missing in table, {len(extra):,} extra in table")
        return Outcome(total=total, message=f"All {len(s):,} keys present in both")

    @qa_check(f"REC-{n_fld:03d}", suite=SET, module=MOD_L, category="Field-level reconciliation", severity="Critical", dataset=ds, defect_area=area,
              title=f"{NAMES[key]}: every column of every record matches between file and table", requires=[key, f"db:{key}"])
    def _fields(ctx, key=key, pk=pk):
        cols = [c["name"] for c in ctx.schema(key)["columns"]]
        res = compare_frames(ctx.typed(key), ctx.db_typed(key), pk, cols)
        return mismatch_outcome(res, "file vs table")


_register_load_checks("dist", 1, 4, 7)
_register_load_checks("fact", 2, 5, 8)
_register_load_checks("cust", 3, 6, 9)


# ======================= B. Distributor Sales  <->  Fact Sales ================
@qa_check("REC-010", suite=SET, module=MOD_X, category="Missing / extra records", severity="Critical",
          dataset="Distributor Sales vs Fact Sales", defect_area="Source data",
          title="Every distributor transaction has a Fact_Sales record and vice-versa", requires=["dist", "fact"])
def rec_dist_fact_coverage(ctx):
    d, f = set(ctx.raw("dist")["distributor_txn_id"]), set(ctx.raw("fact")["distributor_txn_id"])
    rows = [{"distributor_txn_id": k, "failure_reason": "In Distributor Sales, missing in Fact_Sales"} for k in sorted(d - f)] + \
           [{"distributor_txn_id": k, "failure_reason": "In Fact_Sales, missing in Distributor Sales"} for k in sorted(f - d)]
    if rows:
        return Outcome(total=len(d | f), failed=pd.DataFrame(rows), message=f"{len(d - f):,} missing in Fact, {len(f - d):,} missing in Distributor")
    return Outcome(total=len(d | f), message=f"All {len(d):,} transactions exist in both sources")


@qa_check("REC-011", suite=SET, module=MOD_X, category="Field-level reconciliation", severity="Critical",
          dataset="Distributor Sales vs Fact Sales", defect_area="Source data",
          title="Policy, gross, commission, status, timestamps and sale date agree between Distributor Sales and Fact_Sales",
          requires=["dist", "fact"])
def rec_dist_fact_fields(ctx):
    d, f = ctx.typed("dist"), ctx.typed("fact")
    a = d[["distributor_txn_id", "policy_number", "gross_amount", "commission_amount", "status", "created_at", "updated_at"]].copy()
    a["sale_date_key"] = d["sale_date"].dt.strftime("%Y%m%d").astype("Int64") if d["sale_date"].notna().any() else pd.NA
    b = f[["distributor_txn_id", "policy_number", "gross_amount", "commission_amount", "status", "sale_date_key"]].copy()
    b["created_at"], b["updated_at"] = f["src_created_at"], f["src_updated_at"]
    res = compare_frames(a, b, "distributor_txn_id", [c for c in a.columns if c != "distributor_txn_id"])
    return mismatch_outcome(res, "Distributor vs Fact")


# ======================= C. source files  ->  data mart =======================
def _dm_key_set(ctx):
    exp = expected_dm_typed(ctx)
    act = ctx.db_typed("dm")
    return exp, act


@qa_check("REC-020", suite=SET, module=MOD_T, category="Record count", severity="Critical", dataset="Files -> dm_Distributor_Sales_Customer_360",
          defect_area="Target (data mart)", title="Data-mart row count equals expected (APPROVED fact rows joined to distributor on txn+policy)",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_count(ctx):
    f, d = ctx.typed("fact"), ctx.typed("dist")
    waterfall = (f"fact={len(f):,} -> APPROVED={int((f['status'] == 'APPROVED').sum()):,} -> after distributor join & customer left-join="
                 f"{len(ctx.expected_dm()):,}")
    exp, act = len(ctx.expected_dm()), len(ctx.db_raw("dm"))
    return Outcome.from_bool(exp == act, f"Expected={exp:,} Actual={act:,} ({waterfall})",
                             f"Expected={exp:,} Actual={act:,} (diff {act - exp:+,}); {waterfall}",
                             {"expected": exp, "actual": act, "failure_reason": "Row-count mismatch"})


@qa_check("REC-021", suite=SET, module=MOD_T, category="Missing records", severity="Critical", dataset="Files -> dm_Distributor_Sales_Customer_360",
          defect_area="Target (data mart)", title="No expected transactions are missing from the data mart",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_missing(ctx):
    exp, act = _dm_key_set(ctx)
    m = exp[~exp["distributor_txn_id"].isin(set(act["distributor_txn_id"]))][["distributor_txn_id", "sales_sk", "status"]]
    return _key_outcome(m, "distributor_txn_id", exp["distributor_txn_id"].nunique(), "Expected in data mart but MISSING",
                        f"All {exp['distributor_txn_id'].nunique():,} expected transactions are present")


@qa_check("REC-022", suite=SET, module=MOD_T, category="Extra records", severity="Critical", dataset="Files -> dm_Distributor_Sales_Customer_360",
          defect_area="Target (data mart)", title="No unexpected (extra) records exist in the data mart (e.g. REJECTED/CANCELLED)",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_extra(ctx):
    exp, act = _dm_key_set(ctx)
    e = act[~act["distributor_txn_id"].isin(set(exp["distributor_txn_id"]))][["distributor_txn_id", "sales_sk", "status"]]
    return _key_outcome(e, "distributor_txn_id", len(act), "In data mart but NOT expected (extra)", f"No unexpected records among {len(act):,} data-mart rows")


def _dm_field_check(ctx, cols):
    exp, act = _dm_key_set(ctx)
    return mismatch_outcome(compare_frames(exp, act, "distributor_txn_id", cols), "expected vs data mart")


@qa_check("REC-023", suite=SET, module=MOD_T, category="Field-level reconciliation", severity="Critical", dataset="Fact_Sales -> data mart",
          defect_area="Target (data mart)", title="Fact-derived keys, measures, flags and audit dates match the source",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_fact_fields(ctx):
    return _dm_field_check(ctx, FACT_COLS)


@qa_check("REC-024", suite=SET, module=MOD_T, category="Field-level reconciliation", severity="Critical", dataset="Distributor Sales -> data mart",
          defect_area="Target (data mart)", title="Distributor attributes and derived product family/category/flags match the transformation rules",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_dist_fields(ctx):
    return _dm_field_check(ctx, DIST_COLS)


@qa_check("REC-025", suite=SET, module=MOD_T, category="Field-level reconciliation", severity="Critical", dataset="Customer Master -> data mart",
          defect_area="Target (data mart)", title="Customer attributes in the data mart match the Customer Master join result",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_customer_fields(ctx):
    """Validates that the ETL applied its documented join rule. (Whether the join SHOULD match is tested by REF-001/DM-007.)"""
    return _dm_field_check(ctx, CUST_COLS)


@qa_check("REC-026", suite=SET, module=MOD_T, category="Aggregate reconciliation", severity="Critical", dataset="Files -> data mart",
          defect_area="Target (data mart)", title="Aggregates (count, gross, net, commission, tax, discount) agree overall and by product category / distributor",
          requires=["dist", "fact", "cust", "db:dm"])
def rec_dm_aggregates(ctx):
    exp, act = _dm_key_set(ctx)
    measures = ["gross_amount", "net_amount", "commission_amount", "tax_amount", "discount_amount"]
    tol = ctx.thresholds["amount_tolerance"]
    rows, total = [], 0
    for dim in [None, "product_category", "distributor_code", "region_key"]:
        def agg(df):
            g = df.assign(_all="ALL").groupby(dim or "_all", dropna=False)
            out = g.agg(**{"record_count": ("distributor_txn_id", "count"), **{m: (m, "sum") for m in measures}})
            return out
        e, a = agg(exp), agg(act)
        j = e.join(a, how="outer", lsuffix="_exp", rsuffix="_act").fillna(0)
        for grp, r in j.iterrows():
            for m in ["record_count"] + measures:
                total += 1
                if abs(r[f"{m}_exp"] - r[f"{m}_act"]) > (0 if m == "record_count" else tol):
                    rows.append({"dimension": dim or "overall", "group": grp, "metric": m, "expected": round(r[f"{m}_exp"], 2),
                                 "actual": round(r[f"{m}_act"], 2), "difference": round(r[f"{m}_act"] - r[f"{m}_exp"], 2),
                                 "failure_reason": "Aggregate mismatch"})
    if rows:
        return Outcome(total=total, failed=pd.DataFrame(rows), message=f"{len(rows)} aggregate difference(s)")
    return Outcome(total=total, message=f"{total} aggregate figures agree (overall, by product_category, distributor_code, region_key)")
